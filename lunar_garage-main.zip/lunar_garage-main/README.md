# lunar_garage
Highly optimized garage system that allows you to add as many garages as you wish! (car, boat, air)

Documentation: https://lunar-scripts.gitbook.io/lunar-scripts/free-scripts/lunar_garage

Discord: https://discord.gg/zDK4CHQ56N

Dependencies: es_extended, ox_lib, esx_vehicleshop
